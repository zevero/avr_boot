#include <stdint.h>

void initVariant(void);
