Calunium stripboard variant by Steve Marple
Downloaded from: https://github.com/stevemarple/Calunium/blob/master/software/arduino-1.6/calunium/avr/variants/stripboard/pins_arduino.h
